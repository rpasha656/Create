var gulp = require('gulp');
var config = require('../config')();
var del = require('del');

/* Run all clean tasks */
gulp.task('clean', ['clean-build', 'clean-report']);

/* Clean build folder */
gulp.task('clean-build', function () {
    return del([config.tmp]);
});

/* Clean report folder */
gulp.task('clean-report', function () {
    return del([config.report.path]);
});

gulp.task('clean-ts-test', function () {
    return del([config.tmpTest]);
});