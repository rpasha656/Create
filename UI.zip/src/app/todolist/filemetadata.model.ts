export class FileMetadata {
    public accessedOn: Date;
    public documentgroupId: number;
    public documentnameId: number;
    public expirationdate: Date;
    public fileextensionId: number;
    public filename: string;
    public planname: string;
    public publicationdate: Date;
    public sposid: number;
    public statusid: number;

    static clone(filemetadata: FileMetadata): FileMetadata {
        return new FileMetadata(filemetadata.accessedOn,
            filemetadata.documentgroupId,
            filemetadata.documentnameId,
            filemetadata.expirationdate,
            filemetadata.fileextensionId,
            filemetadata.filename,
            filemetadata.planname,
            filemetadata.publicationdate,
            filemetadata.sposid,
            filemetadata.statusid);
    }

    constructor(accessedOn: Date,
        documentgroupId: number,
        documentnameId: number,
        expirationdate: Date,
        fileextensionId: number,
        filename: string,
        planname: string,
        publicationdate: Date,
        sposid: number,
        statusid: number) {
        this.accessedOn = accessedOn;
        this.documentgroupId = documentgroupId;
        this.documentnameId = documentnameId;
        this.expirationdate = expirationdate;
        this.fileextensionId = fileextensionId;
        this.filename = filename;
        this.planname = planname;
        this.publicationdate = publicationdate;
        this.sposid = sposid;
        this.statusid = statusid;
    }

    clear() {
        this.accessedOn = new Date();
        this.documentgroupId = 0;
        this.documentnameId = 0;
        this.expirationdate = new Date();
        this.fileextensionId = 0;
        this.filename = '';
        this.planname = '';
        this.publicationdate = new Date();
        this.sposid = 0;
        this.statusid = 0;
    }
}
