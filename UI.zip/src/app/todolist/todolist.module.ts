import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { FileMetadataService } from './todoservice';
import { CompletedFilterPipe, TodolistComponent } from './index';
// import {ButtonModule} from 'primeng/primeng';
// import { ButtonModule } from 'primeng/primeng';
// import { BlockUIModule } from 'primeng/primeng';
@NgModule({
    declarations: [
        CompletedFilterPipe,
        TodolistComponent
    ],
    imports: [
        FormsModule,
        CommonModule,
        HttpModule
    ],
    providers: [
        FileMetadataService
    ],
    exports: [
        CompletedFilterPipe,
        TodolistComponent
    ]

})
export class TodolistModule {
}
